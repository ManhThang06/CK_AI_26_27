# Task 3 - Kakuro như một bài toán CSP

Bộ giải Kakuro gồm: lọc miền theo từng run (constraint propagation), Backtracking Search
với các heuristic MRV, Degree, LCV, và giao diện PyGame trong đó **solver chạy song song với UI**
và UI hiển thị từng bước của thuật toán khi nó diễn ra.

## 1. Cấu trúc thư mục

```
task3_kakuro/
├── __init__.py
├── __main__.py            # dòng lệnh: solve / bench / test (không cần UI)
├── puzzle.py              # Puzzle: đọc JSON, dựng run, peers, check(); discover_puzzles / load_all
├── requirements.txt       # pygame
├── tests/                 # bộ kiểm thử tự động (unittest), chạy bằng `python -m task3_kakuro test`
├── model/
│   ├── kakuro_model.py    # build_runs, check_model: dựng các Run từ bảng ô, trả về danh sách cảnh báo
│   └── propagation.py     # Run, Propagator, run_state: bảng tổ hợp, node consistency, forward checking, undo
├── solver/
│   ├── heuristics.py      # MRV, Degree (chọn biến), LCV (sắp xếp giá trị)
│   ├── backtracking.py    # BacktrackingSolver, SearchStats, SolveResult
│   ├── trace.py           # TraceRecorder: biến mỗi bước của solver thành một sự kiện (snapshot miền + ngăn xếp phép đoán)
│   └── live.py            # LiveSession: chạy solver trong thread riêng, UI kéo từng sự kiện
├── puzzles/               # MỌI file *.json ở đây đều được CLI và UI tự động nạp
│   ├── assignment_5x5.json
│   ├── assignment_9x9.json
│   ├── assignment_10x10.json
│   └── assignment_12x12.json
└── ui/
    ├── app.py             # giao diện PyGame (chỉ vẽ)
    └── player.py          # LivePlayer: vị trí đang xem, seek, ngăn xếp phép đoán, tổ hợp còn lại, tổng kết
```

Luồng dữ liệu: `puzzles/*.json` -> `Puzzle` -> `BacktrackingSolver` (dùng `Propagator`) chạy trong
thread riêng của `LiveSession` -> `LiveRecorder` đẩy từng sự kiện vào danh sách dùng chung
-> `LivePlayer` -> giao diện. Không có file trace nào được lưu hay đọc lại.

## 2. Cách chạy

Yêu cầu Python 3.10 trở lên. Các lệnh dưới đây chạy từ **thư mục cha** của `task3_kakuro/`
vì code dùng import tương đối.

```bash
pip install -r task3_kakuro/requirements.txt     # chỉ UI cần pygame

# Mở giao diện: solver chạy live trên 9x9 (MRV+Degree, LCV)
python -m task3_kakuro.ui.app
python -m task3_kakuro.ui.app --puzzle task3_kakuro/puzzles/assignment_5x5.json --variable mrv --value asc

# Không cần UI: giải một puzzle (hoặc mọi puzzle trong puzzles/), in nghiệm và thống kê
python -m task3_kakuro solve task3_kakuro/puzzles/assignment_9x9.json
python -m task3_kakuro solve --all
python -m task3_kakuro solve task3_kakuro/puzzles/assignment_9x9.json --variable mrv --value asc --max-nodes 10000

# So sánh các tổ hợp heuristic trên mọi puzzle trong puzzles/
python -m task3_kakuro bench --repeat 20

# Chạy bộ kiểm thử tự động (test giao diện tự bỏ qua nếu chưa cài pygame)
python -m task3_kakuro test
```

Lựa chọn của `--variable`: `first` (baseline), `mrv`, `mrv-degree`.
Lựa chọn của `--value`: `asc` (tăng dần), `lcv`.

Thêm puzzle mới: chỉ cần bỏ một file `.json` vào `puzzles/`; `solve --all`, `bench` và UI (nút `1`..`9`,
phím Tab) tự nhận. File hỏng bị bỏ qua kèm thông báo, không làm hỏng các puzzle còn lại.

### Điều khiển giao diện

| Thao tác | Tác dụng |
|---|---|
| Space, nút Play/Pause | phát / dừng |
| Mũi tên trái / phải | lùi / tiến một sự kiện |
| `G`, nút **Next guess** | nhảy tới phép đoán kế tiếp (bỏ qua chuỗi lan truyền) |
| `B`, nút **Next backtrack** | nhảy tới lần quay lui kế tiếp |
| Bấm / kéo **thanh tiến độ** dưới bàn cờ | nhảy tới vị trí bất kỳ trong các sự kiện đã sinh |
| `R` | về đầu |
| `1`..`9`, Tab, các nút phía trên bàn cờ | chọn puzzle (nút có dấu `!` là puzzle có cảnh báo) |
| `F`, nút Finish | cho solver chạy hết |
| `V` / `C`, các nút Variable / Value | đổi heuristic (chạy lại solver từ đầu) |
| `+` / `-` | đổi tốc độ phát |
| Bấm một ô trắng | xem miền và các run chứa ô đó |

Chụp ảnh không cửa sổ: `python -m task3_kakuro.ui.app --headless --screenshot out.png --event 40`.

### Cách đọc giao diện

- **Ô viền xanh + chữ số xanh dương**: phép đoán (nằm trong ngăn xếp). **Chữ số xanh ngọc**: giá trị
  suy ra do lan truyền. Chữ nhỏ 1..9 là miền còn lại; giá trị vừa bị loại hiện gạch đỏ.
- **Cả run được tô nhạt** khi sự kiện là `propagate` (xanh ngọc) hoặc `contradiction` (đỏ); ô chính là ô đậm hơn.
- **GUESS STACK**: các phép đoán đang mở theo thứ tự; khi quay lui có dòng `undone (r,c)=v`.
- **CELL INSPECTOR**: với mỗi run chứa ô đang chọn: các chữ số đã cố định, tổng còn lại, số ô tự do và
  **các tập chữ số còn hợp lệ** (`sets:`), chính là thứ quyết định giá trị nào bị loại.
- **Thanh tiến độ**: mỗi cột là loại sự kiện nổi bật nhất (xanh dương = đoán, cam = quay lui, đỏ = mâu thuẫn,
  xanh lá = nghiệm); vạch trắng là vị trí đang xem.
- **RESULT**: khi xem sự kiện cuối, hiện kết quả (đã xác minh bằng `Puzzle.check` hay vô nghiệm), số nút,
  số lần quay lui, độ sâu tối đa và thời gian giải thuần của solver (không tính thời gian chờ UI).

### Lỗi thường gặp

- `Could not open requirements file: task3_kakuro/requirements.txt`: bạn đang đứng **bên trong**
  thư mục `task3_kakuro`. Hoặc chạy `pip install -r requirements.txt` tại đó, hoặc `cd ..`
  rồi chạy đúng lệnh ở trên.
- `ImportError: attempted relative import with no known parent package` hoặc `No module named
  task3_kakuro`: phải chạy `python -m ...` từ thư mục **cha** của `task3_kakuro`, không chạy
  trực tiếp `python ui/app.py`.

## 3. Mô hình CSP

- **Biến**: mỗi ô trắng `(r, c)`. 5x5 có 12 biến, 9x9 có 48 biến (10x10: 57, 12x12: 82).
- **Miền**: ban đầu `{1..9}`.
- **Ràng buộc**: mỗi run (dãy ô trắng liên tiếp theo hàng hoặc cột) có hai ràng buộc,
  Alldiff (các ô khác nhau đôi một) và Sum (tổng bằng số gợi ý). Mỗi ô thuộc đúng 2 run.
  Đây là ràng buộc bậc cao nên không dùng AC-3 nguyên bản; xem `model/propagation.py`.

Định dạng ô trong `puzzles/*.json`: `.` ô trắng, `#` ô đen, `d21` gợi ý tổng cột bên dưới,
`a12` gợi ý tổng hàng bên phải, `d14/a12` cả hai.

## 4. Thuật toán

**Lọc miền (`model/propagation.py`)**
- Bảng `COMBOS[(k, S)]` liệt kê các tập k chữ số khác nhau có tổng S.
- Node consistency: lọc từng run một lần trước khi tìm kiếm (`propagate_all`).
- Forward checking: khi gán `cell = v`, `assign` thu miền ô về `{v}` rồi lọc lại hai run
  chứa ô, lặp tới điểm cố định. Hàm trả về `(ok, removed)` với `removed` là danh sách
  `(ô, giá trị, run gây ra)`; `Propagator.undo` dùng danh sách này để hoàn tác khi quay lui.

**Backtracking (`solver/backtracking.py`)**
1. `propagate_all`, nếu thất bại thì puzzle vô nghiệm.
2. Chọn ô chưa xác định (miền từ 2 giá trị trở lên) bằng `VariableSelector`.
3. Sắp xếp giá trị bằng `ValueOrderer`.
4. Với mỗi giá trị: `assign`; thành công thì đệ quy, thất bại thì `undo` và thử giá trị kế.
5. Hết ô chưa xác định thì đã có nghiệm; `Puzzle.check` xác minh lại độc lập.

**Heuristic (`solver/heuristics.py`)**

| Lớp | Vai trò | Quy tắc |
|---|---|---|
| `FirstUnassigned` | baseline | ô chưa gán đầu tiên theo hàng, cột |
| `MRV` | chọn biến | miền nhỏ nhất |
| `MRVDegree` | chọn biến | MRV, hòa thì ô có nhiều ô chưa gán cùng run nhất (Degree) |
| `AscendingOrder` | chọn giá trị | tăng dần |
| `LCV` | chọn giá trị | thử gán từng giá trị bằng `assign`, đếm số giá trị bị loại ở các ô khác rồi hoàn tác; ít nhất thử trước, giá trị dẫn tới mâu thuẫn xếp cuối |

Mọi hòa đều được phá theo thứ tự `(hàng, cột)` hoặc giá trị nhỏ trước nên kết quả tái lập được.
Thêm heuristic mới bằng cách kế thừa `VariableSelector` hoặc `ValueOrderer` và đăng ký
vào `VARIABLE_SELECTORS` / `VALUE_ORDERERS`.

## 5. Kết quả thử nghiệm

Kết quả từ `python -m task3_kakuro bench` (mọi nghiệm đều qua `Puzzle.check`;
thời gian thay đổi theo máy, số nút và số lần quay lui thì cố định):

Hai puzzle chuẩn (đề bài, trang 4 và 5), mỗi puzzle có đúng 1 nghiệm:

| Puzzle | Biến | Giá trị | Nút | Quay lui | Độ sâu tối đa |
|---|---|---|---:|---:|---:|
| 5x5 | mọi tổ hợp | | 1 đến 4 | 0 đến 3 | 1 |
| 9x9 | first | asc | 9 | 2 | 7 |
| 9x9 | first | lcv | 48 | 41 | 7 |
| 9x9 | mrv | asc | 28 | 17 | 11 |
| 9x9 | mrv | lcv | 48 | 37 | 11 |
| 9x9 | mrv-degree | asc | 12 | 3 | 9 |
| 9x9 | mrv-degree | lcv | 18 | 9 | 9 |

Nhận xét: Degree giảm rõ số nút so với MRV thuần (28 xuống 12 với `asc`). Trên puzzle 9x9
này LCV không giúp giảm số nút: puzzle có nghiệm duy nhất, và "ít loại giá trị nhất"
không đồng nghĩa với "đúng", nên LCV tốn thêm chi phí thử gán mà không tránh được nhánh sai.
`first + asc` ít nút nhất (9) chủ yếu do thứ tự quét hàng-cột hợp với puzzle này, không
nên coi là tổng quát. Cần thêm puzzle để kết luận chắc hơn.

### Puzzle `10x10` và `12x12` (vô nghiệm)

Hai file này được nạp và giải như mọi puzzle khác, nhưng **bảng của chúng không hợp lệ về mặt toán học**
nên solver kết luận `unsolvable` ngay ở bước node consistency (0 nút): ví dụ ở 10x10, run D1 gồm 8 ô
mà tổng gợi ý là 23, trong khi tổng nhỏ nhất của 8 chữ số khác nhau là 1+2+...+8 = 36. Ngoài ra có ô chỉ
thuộc 1 run và run chỉ có 1 ô. `Puzzle.warnings` liệt kê các vấn đề này, UI hiện `WARNING` và nút có dấu `!`.
Muốn đo hiệu quả heuristic trên bảng lớn hơn, cần thay bằng bảng 10x10 / 12x12 hợp lệ.

## 6. Solver chạy song song với UI

`solver/live.py` chạy `BacktrackingSolver` trong một thread (daemon). Thuật toán không có
phần code riêng cho UI; `LiveRecorder` (kế thừa `TraceRecorder`) chỉ thêm một bước chờ sau mỗi sự kiện:

1. Mỗi lần solver phát một sự kiện, nó thêm sự kiện vào `session.events` rồi kiểm tra
   hạn mức `limit`. Nếu số sự kiện đã sinh >= `limit` thì thread chờ trên `threading.Condition`.
2. Khi người xem bấm Next/Play tới sự kiện cuối mà solver chưa xong, `LivePlayer` gọi
   `session.demand(n + 1)`; solver sinh đúng một sự kiện nữa rồi lại chờ, và UI tiến lên khi sự kiện tới.
   Nút Finish gọi `session.finish()` để bỏ hạn mức.
3. Lùi lại (Back, Reset) chỉ đọc lại các sự kiện đã có nên không làm solver chạy thêm.
4. Đổi heuristic, đổi puzzle hoặc thoát: `session.stop()` đánh thức thread và hủy bằng `SearchAborted`.

UI chỉ đọc danh sách sự kiện; mỗi sự kiện là snapshot độc lập và được thêm vào danh sách
sau khi dựng xong, nên không cần khóa khi đọc. Bộ đếm hiển thị dạng `007 / 021+` khi tổng
số sự kiện chưa biết, và mất dấu `+` khi tìm kiếm kết thúc.

### Sự kiện

Mỗi sự kiện là một dict gồm `kind`, `cell` (`"r,c"` hoặc `None`), `message`, `removed`, `nodes`,
`backtracks`, `depth`, `guesses` (ngăn xếp các phép đoán đang mở, `[["r,c", giá trị], ...]`)
và `domains` (miền của **tất cả** ô trắng tại thời điểm đó).

| kind | Khi nào phát | Trường thêm |
|---|---|---|
| `start` | miền ban đầu 1..9 | |
| `propagate` | một run loại giá trị khỏi miền một ô (cả ở node consistency và sau mỗi phép gán) | `run` |
| `assign` | phép đoán `cell = value`, message ghi lý do chọn (MRV, Degree, LCV) | `value` |
| `contradiction` | miền rỗng hoặc run không còn tổ hợp hợp lệ | `run` |
| `backtrack` | hoàn tác phép gán, miền được khôi phục | `value`, `restored` |
| `solution` | tìm thấy nghiệm | |
| `exhausted` | duyệt hết mà không có nghiệm | |
| `limit` | dừng vì chạm giới hạn nút | |

## 7. Kiểm thử tự động

`python -m task3_kakuro test` (hoặc `python -m unittest discover -s task3_kakuro/tests -t .`) chạy:

| File | Kiểm tra |
|---|---|
| `test_puzzle.py` | nạp mọi file trong `puzzles/`, thứ tự theo kích thước, cảnh báo của bảng lỗi, `Puzzle.check`, file hỏng bị bỏ qua mà không làm hỏng các file khác |
| `test_propagation.py` | bảng `COMBOS`, `run_state`, lọc miền là đúng đắn (nghiệm luôn còn trong miền), `assign` rồi `undo` khôi phục miền chính xác |
| `test_solver.py` | 6 tổ hợp heuristic giải được mọi puzzle chuẩn, cùng ra một nghiệm duy nhất (đếm độc lập), số nút/quay lui khớp bảng ở mục 5, kết quả lặp lại được, bảng lỗi báo `unsolvable`, giới hạn nút |
| `test_trace_player.py` | luồng sự kiện hợp lệ, ngăn xếp phép đoán khớp độ sâu, `seek`/`jump`/thanh tiến độ, tổ hợp còn lại của run, tổng kết, solver chỉ chạy khi UI yêu cầu và thread được giải phóng khi `stop` |
| `test_cli_ui.py` | `bench` và `solve --all` chạy hết mọi puzzle không lỗi; chụp ảnh UI headless cho từng puzzle (cần pygame, tự bỏ qua nếu chưa cài) |
